<template>
    <div class="personal">
        个人中心
    </div>
</template>
<script>
export default {
    
}
</script>
<style scoped>

</style>


