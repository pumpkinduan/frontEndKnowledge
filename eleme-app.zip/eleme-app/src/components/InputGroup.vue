<template>
  <div class="input-group">
    <section class="input-msg">
      <!-- 手机号码输入框 -->
      <input 
        :type="type" 
        :placeholder="prompt" 
        :maxlength="maxInputLength"
        @input="$emit('input', $event.target.value)"
        :class="{err: error}"
      >
      <!-- 验证码获取按钮 -->
      <button 
        :disabled="disabled" 
        v-if="btnTitle"
        @click="$emit('btnClick')"
        :class="{active: disabled}"
      >{{btnTitle}}</button>
      <!-- 错误信息提示 -->
      <p class="error" v-if="error">
        {{error}}
      </p>
    </section>
  </div>
</template>
<script>
export default {
  props: {
    type: String,
    phoneNumber: String,
    btnTitle: String,
    validatedCode: String,
    prompt: String,
    maxInputLength: String,
    error: String,
    disabled: Boolean
  },
  data() {
    return {
    };
  },
  methods: {
  
  }
};
</script>
<style scoped>
.input-group {
  font-size: 14px;
  color: #999;
}
.input-group .input-msg {
  height: 48px;
  position: relative;
  margin-bottom: 24px;
}
.input-group .input-msg input {
  text-indent: 0.5em;
  border-radius: 4px;
  border: 1px solid #ddd;
  width: 100%;
  height: 100%;
  outline: none;
  box-sizing: border-box;
}
.input-group .input-msg input.err {
  border-color: #f40;
}
.input-group .input-msg input:focus {
  border-color: #0089dc;
}
.input-group .input-msg button {
  border: none;
  color: #0089dc;
  position: absolute;
  top: 50%;
  right: 10px;
  transform: translateY(-50%);
  background: #fff;
  outline: none;
}
.input-group .input-msg button.active {
  color: #ccc;
}
.input-group .input-msg p.error {
  color: red;
  font-size: 12px;
  font-weight: 800;
  position: absolute;
  top: 100%;
  margin-top: 5px;
}
</style>


