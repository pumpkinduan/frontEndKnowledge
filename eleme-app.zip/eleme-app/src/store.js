import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
    location: {},
    address: ''
  },
  getters: {
    location: state => state.location,
    address: state => state.address
  },
  mutations: {
    setLocation(state, location) {
      if ( !location ) { return state.location = null };
      state.location = location;
    },
    setAddress(state, address) {
      if ( !address ) { return state.address = '' };
      state.address = address;
    }
  },
  actions: {
    setLocation({commit}, location) {
      commit('setLocation', location);
    },
    setAddress({commit}, address) {
      commit('setAddress', address);
    }
  }
})
