module.exports = {
    devServer: {
        open: true,//server启动后自动打开浏览器
        host: 'localhost',
        port: 8080,
        https: false,
        hotOnly: false,
        proxy: {//配置跨域
            '/api': {
                //'访问/api ==> target的https://ele-interface.herokuapp.com'
                target: 'https://ele-interface.herokuapp.com', 
                ws: true,
                changeOrigin: true,
                pathWrite: {//路径改写
                     //'访问/api ==> https://ele-interface.herokuapp.com/api'
                    '^/api': '/api'  //https://ele-interface.herokuapp.com/api
                }
            }
        }
    }
}
//在全局在下可结合axios及/api来访问接口服务器