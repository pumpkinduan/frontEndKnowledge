<template>
    <div class="tabBar">
        <router-link
            v-for="(item, index) in data" 
            :key="index"
            class="center"
            :to="{path: item.path}" 
            tag="div"
        >
        <!--
             router-link是自定义标签,或者说是vue封装的一个实例组件
             是没有原生事件的,需要加上修饰符.native告诉vue这个事件是绑定给转换为标签的那个元素
             否则click函数无法执行
         -->
            <i :class="item.icon"></i>
            <p class="font12"> {{ item.title }} </p>
       </router-link>
    </div>
</template>
<script>
export default {
   props: {
       data: Array  
   }
}
</script>
<style scoped>
    .tabBar {
        width: 100vw;
        height: 16vw;
        background: #fbfbfb;
        position: fixed;
        bottom: 0;
        left: 0;
        right: 0;
        box-shadow: 1px 1px 2px rgba(0,0,0,.6);
        display: flex;
        justify-content: space-around;
        align-items: center; 
    }
    .tabBar div {
        display: block;
        flex: 1;
        color: #999;
        padding: 1.2vw 0;
    }
    .tabBar div i {
        display: inline-block;
        margin-bottom: 5px;
        font-size: 18px !important;
    }
    /* router-link被点击激活时,其转换后的那个标签会自动添加该类名,且只在当前路径下 */
    .tabBar div.router-link-exact-active {
        color: #58abde;
        font-weight: 900;
    } 
</style>
