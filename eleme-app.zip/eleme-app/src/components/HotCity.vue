<template>
  <section class="hot">
    <h4>热门城市</h4>
    <ul>
      <li v-for="(item, index) in hotCities" 
      :key="index" 
      @click="skipAddress(item.name)">{{ item.name }}</li>
    </ul>
  </section>
</template>
<script>
export default {
  props: {
    hotCities: Array
  },
  inject: ['skipAddress']
};
</script>
<style scoped>
.hot {
  background-color: #f1f1f1;
  width: 100vw;
  padding: 5vw 10vw 5vw 0;
  box-sizing: border-box;
}
.hot ul {
  display: flex;
  justify-content: space-between;
  flex-wrap: wrap;
  height: 140px;
}
.hot h4 {
  padding: 12px 0 12px 16px;
  font-size: 15px;
  color: #180f0f;
}
.hot ul li {
  box-sizing: border-box;
  color: #232323;
  font-weight: bold;
  width: 20vw;
  height: 60px;
  border-radius: 8px;
  background-color: #fff;
  line-height: 60px;
  text-align: center;
  font-size: 15px;
  align-self: center;
}
</style>


