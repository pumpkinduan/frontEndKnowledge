<template>
  <div class="index">
    <router-view/>
    <tabBar :data="arrLists"/>
  </div>
</template>

<script>
// @ is an alias to /src
import tabBar from "@/components/TabBar.vue";
export default {
  data() {
    return {
      arrLists: [
        {
          title: "首页",
          icon: "iconfont icon-shouye",
          path: "/home",
        },
        {
          title: "订单",
          icon: "iconfont icon-order_icon",
          path: "/order",
        },
        {
          title: "我的",
          icon: "iconfont icon-wode",
          path: "/personal",
        }
      ]
    };
  },
  components: {
    tabBar
  }
};
</script>
<style scoped>
.index {
  height: calc(100vh - 16vw);
}
</style>

