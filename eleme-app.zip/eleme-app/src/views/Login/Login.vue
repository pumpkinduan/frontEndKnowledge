<template>
  <div class="login">
    <div class="login-inner">
      <div class="logo-img">
        <img src="http://shadow.elemecdn.com/faas/h5/static/logo.ba876fd.png" alt>
      </div>
      <input-group
        :btnTitle="btnTitle"
        type="text"
        :prompt="prompt"
        v-model="phoneNumber"
        maxInputLength="11"
        :error="errors.phoneNumber"
        @btnClick="getVertifyCode"
        :disabled="disabled"
      />
      <input-group
        type="text"
        prompt="验证码"
        v-model="validatedCode"
        maxInputLength="6"
        :error="errors.validatedCode"
      />
      <p>
        新用户登录即自动注册，并表示已同意
        <a href="javascript:;" class="blue">《用户服务协议》</a>
      </p>
      <button class="loginBtn" @click="handleLogin" :disabled="isClicked">登录</button>
      <p class="center">
        <a href="#">关于我们</a>
      </p>
    </div>
  </div>
</template>

<script>
import inputGroup from "@/components/InputGroup.vue";
export default {
  data() {
    return {
      phoneNumber: "",
      btnTitle: "获取短信验证码",
      validatedCode: "",
      prompt: "手机号码",
      disabled: false,
      errors: {
        phoneNumber: "",
        validatedCode: ""
      }
    };
  },
  computed: {
    isClicked() {
      return !this.phoneNumber || !this.validatedCode ? true : false;
    }
  },
  components: {
    inputGroup
  },
  methods: {
    validatePhoneNum() {
      //对手机号进行校核
      if (!this.phoneNumber) {
        //手机号码为空
        this.errors.phoneNumber = "手机号码不能为空";
        return false;
      } else {
        if (/^1[345678]\d{9}$/.test(this.phoneNumber)) {
          this.errors = {};
          return true;
        } else {
          this.errors.phoneNumber = "手机号码错误";
          return false;
        }
      }
    },
    getVertifyCode() {
      //获取验证码
      if (!this.validatePhoneNum()) {
        return false;
      } else {
        //设置倒计时
        this.setCounterDown();
        //发送网络请求
        this.$axios
          .get("http://localhost:8888/getVertifyCode", {
            params: {
              mobile: this.phoneNumber
            }
          })
          .then(data => {
            alert('验证码为:' + data.data.code);
          })
          .catch(err => {
            console.log(err);
          });
      }
    },
    setCounterDown() {
      //设置倒计时
      let time = 30;
      this.disabled = true;
      this.btnTitle = time + "秒后重新获取";
      let timerId = setInterval(() => {
        if (time === 0) {
          clearInterval(timerId);
          this.disabled = false;
          this.btnTitle = "获取短信验证码";
          return;
        }
        time--;
        this.btnTitle = time + "秒后重新获取";
      }, 1000);
    },
    handleLogin() {
      this.$axios
        .get("http://localhost:8888/login", {
          params: {
            mobile: this.phoneNumber,
            validatedCode: this.validatedCode
          }
        })
        .then(dataObj => {
          if ( !dataObj ) return; 
          if ( dataObj.data.statusCode !== 0 ) {
          //向浏览器端写入一段信息表示登录成功,这样不会受到前面设置的全局守卫的影响而可以访问其他页面
            localStorage.setItem("elem_login", true);
            this.$router.push("/");//登录成功跳转到首页
            this.errors = {};//届时清空errors的信息,保证实效性
          } else {
            this.errors.validatedCode = dataObj.data.reason;
          }
        });
    }
  }
};
</script>

<style scoped>
.login {
  width: 100%;
  height: 100%;
  box-sizing: border-box;
  padding-top: 40px;
}
.login .login-inner {
  margin: 0 auto;
  width: 300px;
  font-size: 14px;
  color: #999;
}
.login .login-inner .loginBtn {
  background-color: #209d35;
  color: #fff;
  font-weight: bolder;
  width: 100%;
  font-size: 18px;
  padding: 12px 0;
  border-radius: 4px;
  border: none;
  margin-top: 20px;
  margin-bottom: 16px;
  outline: none;
}
.login .login-inner .loginBtn[disabled] {
  background-color: #69d37b;
}
.login .logo-img {
  vertical-align: top;
  text-align: center;
  padding-bottom: 15px;
}
.login .logo-img img {
  height: 56px;
  max-width: 100%;
}
.login .login-inner p a {
  font-size: 14px;
  margin-top: 8px;
}
</style>
