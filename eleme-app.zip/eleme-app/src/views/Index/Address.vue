<template>
  <div class="address">
    <Header 
     title="选择收货地址"
     subTitle= "新增地址"
     isBackUpIcon=true
    />
    <section class="location-desc">
      <span class="city" @click="enterCityPage(city)">{{ city }}</span>
      <i class="iconfont icon-xiajiantou"></i>
      <div class="search-box">
        <i class="iconfont icon-sousuo"></i>
        <input type="text" placeholder="请输入地址" v-model="search_word">
      </div>
    </section>
    <CurrentLocation v-if="!search_word"
      title="当前地址"
      :addr="address"
    />
    <ul v-else >
      <li 
        v-for="(item,index) in addrLists" 
        :key="index"
        @click="selectAddress(item)"
        >
        <h4> {{ item.district }} </h4>
        <p> {{ item.district }}{{ item.address }} </p>
      </li>
    </ul>
  </div>
</template>
<script>
import Header from '@/components/Header.vue';
import CurrentLocation from '@/components/CurrentLocation.vue';
export default {
  data() {
    return {
      search_word: "",
      addrLists: []
    };
  },
  components: {
      Header,
      CurrentLocation
  },
  computed: {
    city() {
      return this.$route.params.city;
    },
    address() {
      return this.$store.getters.location.formattedAddress;
    }
  },
  beforeRouteEnter(to, from, next) {
      //容错
      //可能由于网速原因获取地址信息较慢
    if (to.params.city) {
      next();
    } else {
      next("/home");
    }
  },
  watch: {
    search_word() {
        this.searchInfo();
    }
  },
  methods: {
    searchInfo() {
      const self = this;
      AMap.plugin("AMap.Autocomplete", function() {
        // 实例化Autocomplete
        var autoOptions = {
          //city 限定城市，默认全国
          city: self.city
        };
        var autoComplete = new AMap.Autocomplete(autoOptions);
        autoComplete.search(self.search_word, function(status, result) {
          // 搜索成功时，result即是对应的匹配数据
          self.addrLists = result.tips;
        });
      });
    },
    selectAddress(addr) {
        this.$store.dispatch('setAddress', addr.district + addr.address);
        this.$router.push('/')
    },
    enterCityPage(city) {
        this.$router.push({name: 'City', params: {
            city: city
        }})
    }
  }
};
</script>
<style scoped>
.address {
  width: 100vw;
  height: 100vh;
  background: #eee;
}
.address .location-desc {
  background-color: #fff;
  font-size: 12px;
  color: #222;
  padding: 10px 16px;
  box-sizing: border-box;
}
.address .location-desc .icon-xiajiantou {
  display: inline-block;
  margin: 0 8px;
}
.address .location-desc .search-box {
  font-size: 16px;
  color: #999;
  background: #f1f1f1;
  display: inline-block;
}
.address .location-desc .search-box input {
  border: none;
  outline: none;
  width: 65vw;
  height: 12vw;
  text-indent: 5px;
  background: #f1f1f1;
  border-radius: 8px;
}
.address ul {
    max-height: 75vh; 
    overflow: scroll;
}
.address ul li {
  padding: 14px 16px;
  background: #fff;
  font-size: 14px;
  color: #222;
  border-bottom: 1px solid #eee;
}
.address ul li h4 {
  color: #223;
  font-weight: bolder;
  font-size: 20px;
  margin-top: 2px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.address ul li p {
  padding-top: 10px; 
  width: 80%;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.icon-sousuo {
  margin-left: 5px;
}
</style>
