<template>
  <div class="rating">
    <ul class="solid_star">
      <li
        v-for="(rate, index) in MAX_COUNTS"
        :key="index"
        :style="{width: widthArr[index] * 16 + 'px'}"
      >
        <i class="iconfont icon-icon-"></i>
      </li>
    </ul>
    <!-- 十分巧妙的一种做法,在没有对应星级icon时采用,css设置麻烦了点 -->
    <div class="empty_star">
      <span class="iconfont icon-icon-" v-for="item in MAX_COUNTS" :key="item"></span>
    </div>
  </div>
</template>
<script>
export default {
  props: {
    rating: Number
  },
  created() {
    this.formate();
  },
  data() {
    return {
      MAX_COUNTS: 5, //星星的最大数量
      widthArr: [] // [1,1,1,1,.6] 4.6
    };
  },
  methods: {
    formate() {
      let integer = Math.floor(this.rating);
      let float = Number((this.rating - integer).toFixed(2));
      while (integer) {
        this.widthArr.push(1);
        integer--;
      }
      this.widthArr.push(float);
      if (this.widthArr.length !== this.MAX_COUNTS) {
        //solve like 3.8 => [1,1,1,.8,0]
        let left = this.MAX_COUNTS - this.widthArr.length;
        while (left) {
          this.widthArr.push(0);
        }
      }
    }
  }
};
</script>
<style scoped>
.rating {
  position: relative;
  overflow: hidden;
}
.solid_star {
  position: absolute;
  display: inline-block;
  height: 16px;
  width: 80px;
  z-index: 0;
}
.solid_star li {
  width: 16px;
  height: 16px;
  position: absolute;
  left: 0;
  overflow: hidden;
}
.solid_star li:nth-child(2) {
  left: 16px;
}
.solid_star li:nth-child(3) {
  left: 32px;
}
.solid_star li:nth-child(4) {
  left: 48px;
}
.solid_star li:nth-child(5) {
  left: 64px;
}
.solid_star li i.icon-icon- {
  color: transparent;
  background-clip: text;
  background-color: tomato;
}
span.icon-icon- {
  display: inline-block;
  color: #ccc;
  overflow: hidden;
}
</style>


