### node server.js 开启该服务器

server.js文件是用node搭建的本地短信验证码接口,
该接口利用了CORS的方式来解决跨域问题
主要是模拟短信后台接口部分
--------------------------
> 它可以处理两种url:
1. http://localhost:8888/getVertifyCode
   用来获取验证码(随机的6位数)
   
    获取验证码成功返回的示例
    {
        statusCode: 1,
        code: String
    }

2. http://localhost:8888/login
   登录时用来校核手机号与验证码是否相一致

    校核验证码成功返回的示例
    {
        reason: 'success',
        statusCode: 1,
        code
    }

    校核验证码失败返回的示例
    {
        reason: '验证码错误',
        statusCode: 0,
    }