<template>
  <section class="location">
     <ul class="cur-address-wrap">
      <span class="title">{{ title }}</span>
      <li class="cur-address" @click="selectAddress(addr)">
        <h4>{{addr}}</h4>
      </li>
    </ul>
  </section>
</template>
<script>
export default {
  props: {
    title: String,
    addr: String
  },
  methods: {
    selectAddress(addr) {
        this.$store.dispatch('setAddress', addr);
        this.$router.push('/');
    }
  }
};
</script>
<style scoped>
.location ul li {
  padding: 14px 16px;
  background: #fff;
  font-size: 14px;
  color: #222;
  border-bottom: 1px solid #eee;
}
.location ul li h4 {
  color: #223;
  font-weight: bolder;
  font-size: 20px;
  margin-top: 2px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.location ul .title {
  background-color: #f1f1f1;
  display: block;
  padding: 16px 0 16px 16px;
}
</style>


