<template>
  <div :class="{'show-mask': isSort || isScreen, box: true}" @click.self="hide">
    <div class="filter-wrap">
      <div :class="{'wrap': true, 'scrollTop': isSort}">
        <ul class="filter-nav">
          <li
            v-for="(item, index) in filterData.navTab"
            :key="index"
            :class="{'icon-xiala iconfont': index===0, 'iconfont icon-40': index===3, 'nav-active': index===activeIndex}"
            @click="selectSort(index, item)"
          >{{ item.name }}</li>
        </ul>
        <ul class="filter-sort" v-if="isSort">
          <li
            v-for="(item, index) in filterData.sortBy"
            :key="index"
            @click="filterExtend(index, item)"
            :class="{'extend-active': index===activeExtendIndex}"
          >
            <span>{{ item.name }}</span>
            <i v-show="index===activeExtendIndex" class="iconfont icon-hook"></i>
          </li>
        </ul>
        <FilterScreen :filterScreen="filterData.screenBy" v-if="isScreen"/>
      </div>
    </div>
  </div>
</template>
<script>
import FilterScreen from "@/components/FilterScreen";
export default {
  props: {
    filterData: Object
  },
  components: {
    FilterScreen
  },
  data() {
    return {
      activeIndex: 0,
      activeExtendIndex: 0,
      isSort: false,
      isScreen: false
    };
  },
  methods: {
    selectSort(index, item) {
      switch (index) {
        //添加蒙版
        case 0:
          this.isSort = true;
          this.$emit("fixedTop", this.isSort);
          break;
        case 1:
          //按条件更新商品列表排序
          this.hide();
          this.update(item.condition);
          break;
        case 2:
          this.hide();
          this.update(item.condition);
          break;
        case 3:
          //显示筛选列表
          this.isScreen = true;
          this.$emit("fixedTop", this.isScreen);
          break;
      }
      this.activeIndex = index;
    },
    hide() {
      //取消蒙版
      this.isSort = false;
      this.isScreen = false;
      //让搜索框定位到顶部
      this.$emit("fixedTop", this.isSort || this.isScreen);
    },
    update(condition) {
      this.$emit("updateView", { condition: condition });
    },
    //综合排序扩展
    filterExtend(index, item) {
      this.isSort = false;
      this.activeExtendIndex = index;
      this.$parent.filterData.navTab[0].name = item.name;
      this.update(item.code);
    }
  }
};
</script>
<style scoped>
.box {
  position: sticky;
  top: 18vw;
  background: #fafafa;
  z-index: 1;
}
.show-mask {
  position: fixed;
  top: 18vw;
  width: 100vw;
  height: 100vh;
  background: rgba(0, 0, 0, 0.5);
  z-index: 99;
  transition: all 0.5s;
  box-sizing: border-box;
}
/* navTab */
.filter-wrap .filter-nav {
  background-color: #fff;
  font-size: 15px;
  color: #666;
  display: flex;
  justify-content: space-around;
  height: 15vw;
  align-items: center;
}
.filter-wrap .filter-nav li {
  padding: 2vw 3vw;
}
.nav-active {
  font-weight: bold;
}

/* 综合排序展开 */
.filter-wrap .filter-sort {
  background-color: #fff;
  padding-left: 6vw;
}
.filter-wrap .filter-sort li {
  color: #333;
  font-size: 14px;
  padding: 4vw 0;
}
.extend-active {
  font-weight: 700;
  color: #3190e8 !important;
  display: flex;
  justify-content: space-between;
}
/* --综合排序展开-- */
</style>


