<template>
  <div class="filterScreen">
    <div class="screen-inner">
      <dl v-for="(screen, index) in filterScreen" :key="index">
        <dt>{{screen.title}}</dt>
        <dd>
          <div
            v-for="(curItem, i) in screen.data"
            :Key="i"
            @click="selectScreen(screen, curItem)"
            :class="{selected: curItem.select}"
          >
            <img
              :src="curItem.icon"
              style="width: 3.4vw;height:3.4vw;vertical-align:middle;margin-right:2px;"
              v-if="curItem.icon"
            >
            <span style="vertical-align:middle;">{{curItem.name}}</span>
          </div>
        </dd>
      </dl>
    </div>
    <section class="screen-btn-wrap">
      <span :class="{'clear-btn': true, ok: clear_ok}" @click="clearAllSelec">清空</span>
      <span class="ok-btn" @click="filterAct">确定</span>
    </section>
  </div>
</template>
<script>
export default {
  props: {
    filterScreen: Array
  },
  data() {
    return {
      clear_ok: false
    };
  },
  methods: {
    selectScreen(curScreen, curItem) {
      this.clear_ok = true; //可清空
      if (curScreen.id !== "MPI") {
        //单选
        curScreen.data.forEach(item => {
          item.select = false;
        });
        curItem.select = !curItem.select;
      } else {
        //多选
        curItem.select = !curItem.select;
      }
    },
    clearAllSelec() {
      //清空所有已选择
      if (!this.clear_ok) return;
      this.filterScreen.forEach(ele => {
        ele.data.forEach(item => {
          item.select = false;
        });
      });
      this.clear_ok = false;
    },
    filterAct() {
        this.$parent.hide();
    }
  }
};
</script>
<style scoped>
.filterScreen {
  border-top: 1px solid #dddddd;
  background-color: #fff;
}
.filterScreen .screen-inner {
  padding: 2vw 2.667vw 0 2.667vw;
}
.filterScreen dl {
  color: #999;
  margin-bottom: 3vw;
}
.filterScreen dl dd {
  width: 100%;
  display: flex;
  margin-top: 1vw;
  flex-wrap: wrap;
}
.filterScreen dl dd div {
  /* flex: 0 0 33.33%; */
  width: 30%;
  background-color: #fafafa;
  text-align: center;
  padding: 5px 3px;
  margin-right: 2vw;
  box-sizing: border-box;
  margin-top: 2vw;
  line-height: 8vw;
}
.screen-btn-wrap {
  margin-top: 5vw;
  border-top: 1px solid #eee;
}
.screen-btn-wrap span {
  display: inline-block;
  vertical-align: top;
  width: 50%;
  line-height: 10vw;
  text-align: center;
  font-size: 0.13rem;
  color: rgba(0, 0, 0, 0.3);
  font-weight: 600;
}
.screen-btn-wrap span.ok-btn {
  color: #fff;
  background-color: #00d762;
}
.screen-btn-wrap .clear-btn.ok {
  color: #333;
}
.selected {
  font-weight: 700;
  color: #3190e8;
  background-color: #edf5ff !important;
}
</style>


