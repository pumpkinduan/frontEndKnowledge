<template>
  <section class="alphabet" ref="scroll_area">
    <div class="right">
      <a v-for="(letter, index) in cityKeys" :key="index" :href="'#' + letter">{{letter}}</a>
    </div>
    <ul class="city-wrap">
      <li v-for="(val, i) in cityKeys" :key="i" :id="val">
        <h4>{{val}}</h4>
        <div class="inner">
          <p
            v-for="(item, index) in cityInfos[val]"
            :key="index"
            @click="skipAddress(item.name)"
          >{{item.name}}</p>
        </div>
      </li>
    </ul>
  </section>
</template>
<script>
import BScroll from "better-scroll";
export default {
  props: {
    cityInfos: Object,
    cityKeys: Array
  },
  inject: ["skipAddress"],
  methods: {
    initScroll() {
      let scroll = new BScroll(this.$refs.scroll_area, {
        //纵向可点击的滑动
        click: true,
        scrollY: true
      });
    }
  }
};
</script>
<style scoped>
section {
  height: 40vh;
}

section .right {
  position: fixed;
  right: 0;
  top: 32%;
}
section .right a {
  display: block;
  padding: 4px 8px;
  color: #888;
  font-size: 14px;
}

section ul.city-wrap li {
  background-color: #fff;
}
section ul.city-wrap li h4 {
  padding: 12px 0 12px 16px;
  background-color: #f1f1f1;
  color: #666;
  font-size: 18px;
  font-weight: 600;
}
section ul.city-wrap li .inner {
  padding-left: 16px;
}
section ul.city-wrap li .inner p {
  padding: 12px 0;
  border-bottom: 1px solid #eee;
  color: #333;
  font-size: 16px;
}
</style>

