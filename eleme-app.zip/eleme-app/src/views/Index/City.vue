<template>
  <section class="cur-City">
    <Header title="城市选择" isBackUpIcon="true"/>
    <div class="search-input">
      <div class="inner">
        <i class="iconfont icon-sousuo"></i>
        <input type="text" placeholder="输入城市名或拼音" v-model="key_word">
      </div>
    </div>
    <CurrentLocation title="当前地位城市" :addr="city" v-if="city && !key_word"/>
    <HotCity :hotCities="hotCities" v-if="!key_word"/>
    <Alphabet :cityKeys="cityKeys" :cityInfos="cityInfos" v-if="!key_word" ref="allCities"/>
    <ul v-else class="select-city">
      <li v-for="(item, index) in searchCityList" :key="index" @click="skipAddress(item)">{{item}}</li>
    </ul>
  </section>
</template>
<script>
import Header from "@/components/Header.vue";
import Alphabet from "@/components/Alphabet.vue";
import HotCity from "@/components/HotCity.vue";
import CurrentLocation from "@/components/CurrentLocation.vue";
export default {
  created() {
    this.getAllCities();
  },
  data() {
    return {
      key_word: "",
      cityInfos: {},
      cityKeys: [],
      allCities: [],
      searchCityList: [],
      hotCities: []
    };
  },
  provide() {//提供给后代
    return {
      skipAddress: this.skipAddress
    }
  },
  watch: {
    key_word() {
      this.getSearchCities();
    }
  },
  computed: {
    city() {
      return this.$route.params.city;
    },
    upperCaseKeyWord() {
      return this.key_word.toUpperCase();
    }
  },
  beforeRouteEnter(to, from, next) {
    //容错
    if (to.params.city) {
      next();
    } else {
      next("/");
    }
  },
  components: {
    Header,
    CurrentLocation,
    Alphabet,
    HotCity
  },
  methods: {
    getAllCities() {
      this.$axios
        .get("/api/posts/cities")
        .then(result => {
          console.log(result.data);
          this.cityKeys = Object.keys(result.data);
          this.cityKeys.pop(); //移除 hotCities
          this.cityKeys.sort();

          this.cityInfos = result.data;
          this.hotCities = this.cityInfos["hotCities"]; //热门城市
          this.cityKeys.forEach((key, index) => {
            //存储所有城市
            this.cityInfos[key].forEach(item => {
              this.allCities.push(item.name);
            });
          });

          this.$nextTick(function() {
            //数据加载完后初始化滚轮区域,使其可滚动
            //注意:它在DOM更新前,数据更新后执行
            this.$refs.allCities.initScroll();
          })
        })
        .catch(function(err) {
          console.log(err);
        });
    },
    getSearchCities() {
      if (this.isEnglishWord(this.key_word)) {
        let keyFirst = this.upperCaseKeyWord[0]; //检索词的首位
        if (this.upperCaseKeyWord.length === 1) {
          this.cityInfos[keyFirst].forEach(item => {
            this.searchCityList.push(item.name);
          });
        } else {
          this.searchCityList = []; //防止检索不准确
          this.cityInfos[keyFirst].forEach(item => {
            //返回 根据两个检索单词 可查询的结果
            //item.abbr 是 城市名字的首字母的大写
            //安庆 => AQ
            if (item.abbr.includes(this.upperCaseKeyWord.substr(0, 2))) {
              this.searchCityList.push(item.name);
            }
          });
        }
      } else {
        //非英文单词查询
        this.searchCityList = [];
        this.searchCityList = this.allCities.filter((item, index) => {
          if (item.includes(this.key_word)) {
            return true;
          }
        });
      }
    },
    isEnglishWord(str) {
      if (str.charCodeAt(0) >= 65 && str.charCodeAt(0) <= 90) {
        return true;
      } else if (str.charCodeAt(0) >= 97 && str.charCodeAt(0) <= 122) {
        return true;
      }
    },
    skipAddress(cityName) {
      this.$router.push({
        name: "Address",
        params: {
          city: cityName
        }
      });
    }
  }
};
</script>
<style scoped>
.search-input {
  padding: 12px 20px;
  text-align: center;
}
.search-input .inner {
  background-color: #f2f2f2;
  border-radius: 10px;
}
.search-input input {
  border: none;
  outline: none;
  font-size: 12px;
  color: #999;
  width: 90%;
  height: 12vw;
  background-color: #f2f2f2;
  text-indent: 1em;
}
.icon-sousuo {
  vertical-align: -2px;
}
.select-city {
  background-color: #fff;
  padding-left: 16px;
}
.select-city li {
  padding: 12px 0;
  border-bottom: 1px solid #eee;
  color: #333;
  font-size: 16px;
}
</style>


