import Vue from 'vue';
import Router from 'vue-router';
import Index from '@/views/Index/Index.vue';
//realize lazy loading
const Login = () => import('@/views/Login/Login.vue');

Vue.use(Router);

const router = new Router({
  mode: 'history',
  base: process.env.BASE_URL,
  routes: [
    {
      path: '/',
      name: 'Index',
      redirect: '/home',
      component: Index,
      children: [
        {
          path: 'home',
          name: 'Home',
          component: () => import('@/views/Index/Home.vue')
        },
        {
          path: 'order',
          name: 'Order',
          component: () => import('@/views/Index/Order.vue')
        },
        {
          path: 'personal',
          name: 'Personal',
          component: () => import('@/views/Index/Personal.vue')
        },
        {
          path: 'address',
          name: 'Address',
          component: () => import('@/views/Index/Address.vue')
        },
        {
          path: 'city',
          name: 'City',
          component: () => import('@/views/Index/City.vue')
        }
      ]
    },
    {
      path: '/login',
      name: 'Login',
      /* 
        route level code-splitting
        this generates a separate chunk (about.[hash].js) for this route
        which is lazy-loaded when the route is visited.
        component: () => import('@/views/Login/login.vue')
      */
      component: Login
    }
  ]
});
//全局的路由守卫,需登录才能访问需要的页面
router.beforeEach((to, from, next) => {
  const isLogin = localStorage.elem_login ? true : false;
  if (to.path === '/login') {
    next();
  } else {
    isLogin ? next() : next('/login');
  }
});
export default router;

