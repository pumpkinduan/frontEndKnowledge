<template>
  <div class="home">
    <header>
      <h2 @click="$router.push({name: 'Address', params:{'city': city}})">
        <i class="iconfont icon-dingwei"></i>
        <span>{{ address }}</span>
      </h2>
    </header>
    <section :class="{fixedTop: isFixed, 'serach-box': true}">
      <div class="search">
        <i class="iconfont icon-sousuo"></i>
        <input type="text" placeholder="搜索饿了么商家,商品名称">
      </div>
    </section>

    <!-- 轮播广告 -->
    <div class="swipe-wrap">
      <mt-swipe :auto="3000">
        <mt-swipe-item v-for="(item, index) in swipeImgs" :key="index">
          <img :src="item">
        </mt-swipe-item>
      </mt-swipe>
    </div>
    <!-- /轮播广告 -->

    <!-- 轮播条目 -->
    <div class="entries-wrap">
      <mt-swipe :auto="0">
        <mt-swipe-item v-for="(item, index) in entries" :key="index">
          <a v-for="(v, i) in item" :key="i">
            <div class="container">
              <img :src="v.image">
              <span class="title">{{v.name}}</span>
            </div>
          </a>
        </mt-swipe-item>
      </mt-swipe>
    </div>
    <!-- /轮播条目 -->

    <!-- 推荐商家 -->
    <div class="shoplist-title center">推荐商家</div>
    <!-- /推荐商家 -->

    <!-- 筛选商店 -->
    <FilterShop :filterData="filterData" @fixedTop="fixedTop" @updateView="updateView"/>
    <!-- /筛选商店 -->

    <!-- 上拉刷新和下拉加载 -->
    <mt-loadmore
      :top-method="loadData"
      ref="loadmore"
      :bottom-method="loadMore"
      :bottom-all-loaded="allLoaded"
      :bottomPullText="bottomPullText"
      :autoFill="false"
    >
      <!-- 餐店展示 -->
      <div>
        <Restaurant
          v-for="(restaurant, index) in restaurants"
          :key="index"
          :restaurant="restaurant.restaurant"
        />
      </div>
    </mt-loadmore>
  </div>
</template>
<script>
import { Swipe, SwipeItem, Loadmore } from "mint-ui";
import FilterShop from "@/components/FilterShop";
import Restaurant from "@/components/Restaurant";
export default {
  components: {
    [Swipe.name]: Swipe,
    [SwipeItem.name]: SwipeItem,
    FilterShop,
    Restaurant,
    Loadmore
  },
  created() {
    this.getData();
  },
  computed: {
    address() {
      return this.$store.getters.address;
    },
    city() {
      return this.$store.getters.location.addressComponent.city;
    }
  },
  data() {
    return {
      swipeImgs: [], //轮播图片
      entries: [], //条目
      filterData: {},
      isFixed: false,
      restaurants: [],
      allLoaded: false,
      bottomPullText: "上拉加载更多", //显示在底部的文字
      page: 1, //请求的第一页数据
      size: 5 //每次请求的数据条数
    };
  },
  methods: {
    getData() {
      this.$axios.get("/api/profile/shopping").then(res => {
        this.swipeImgs = res.data.swipeImgs;
        this.entries = res.data.entries;
      });
      this.$axios.get("/api/profile/filter").then(result => {
        this.filterData = result.data;
      });
      this.loadData();
    },
    loadData(condition) {
      this.page = 1;
      this.allLoaded = false;
      this.bottomPullText = "上拉加载更多";
      this.$axios
        .post(`api/profile/restaurants/${this.page}/${this.size}`, condition)
        .then(res => {
          this.restaurants = res.data;
          this.$refs.loadmore.onTopLoaded(); //下拉刷新结束 remove topLoadingText
        });
    },
    fixedTop(bool) {
      this.isFixed = bool;
    },
    updateView(condition) {
      this.loadData(condition);
    },
    loadMore() {
      if (this.allLoaded) return;
      this.page++;
      //上拉加载
      this.$axios
        .post(`api/profile/restaurants/${this.page}/${this.size}`)
        .then(res => {
          this.$refs.loadmore.onBottomLoaded();
          if (res.data.length === 0) {
            //数据为空
            this.allLoaded = true;
            this.bottomPullText = "没有更多内容了";
          }
          if (res.data.length > 0) {
            //有数据
            if (res.data.length < this.size) {
              //返回的数据条数小于一页的数据量,表示数据库里再没有数据了
              res.data.forEach(item => {
                //渲染
                this.restaurants.push(item);
              });
              this.allLoaded = true;
              this.bottomPullText = "没有更多内容了";
            } else {
              res.data.forEach(item => {
                this.restaurants.push(item);
              });
              return;
            }
          }
        });
    }
  }
};
</script>
<style scoped>
.mint-loadmore {
  height: calc(100% - 36vw);
  overflow: auto;
}
.home {
  width: 100%;
  box-sizing: border-box;
  height: 100%;
  overflow: auto;
}
.home header {
  height: 12vw;
  background: linear-gradient(90deg, #0af, #0085ff);
  padding: 0.2rem 0.1rem 0 0.1rem;
}
.home header h2 i.icon-dingwei {
  font-size: 0.2rem;
  font-weight: bolder;
  color: #fff;
}
.home header h2 span {
  vertical-align: text-top;
  margin-left: 4px;
  font-size: 0.16rem;
  display: inline-block;
  width: 80vw;
  font-weight: bolder;
  color: #fff;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.home section.serach-box {
  position: sticky;
  top: 0;
  padding: 0.1rem 0.1rem;
  background: linear-gradient(90deg, #0af, #0085ff);
  box-sizing: border-box;
  height: 18vw;
  z-index: 9;
}
.home section.fixedTop {
  width: 100%;
  position: fixed;
  top: 0;
  z-index: 999;
}
.home section.serach-box .search {
  font-size: 0.14rem;
  line-height: 12vw;
  height: 12vw;
  color: #999;
  background-color: #fff;
}

.home section.serach-box .search input {
  width: 80%;
  outline: none;
  height: 100%;
  border: none;
  text-indent: 2px;
}
.home section.serach-box .search .icon-sousuo {
  font-weight: bolder;
  font-size: 0.14rem;
  margin-left: 2px;
}

/* 轮播广告 */
.home .swipe-wrap {
  height: 23vw;
}
.home .swipe-wrap img {
  width: 100%;
}
/* --轮播广告-- */

/* 轮播条目 */
.home .entries-wrap {
  background-color: #eeeeee40;
  padding-top: 5vw;
  height: 47vw;
  text-align: center;
}
.home .entries-wrap a {
  float: left;
  width: 20%;
  margin-top: 6px;
}
.home .entries-wrap .container {
  width: 15vw;
  height: 15vw;
  display: inline-block;
}
.home .entries-wrap .container img {
  width: 100%;
  height: 100%;
  display: block;
}
/* --轮播条目-- */

/* 推荐商家 */
.home .shoplist-title {
  display: flex;
  justify-content: center;
  align-items: center;
  font-size: 16px;
  color: #222;
  height: 10.6vw;
  font-weight: bold;
}
.home .shoplist-title::before,
.home .shoplist-title::after {
  background-color: #999;
  height: 0.467vw;
  width: 5.7vw;
  content: "";
  display: block;
  margin: 0 10px;
}
/* --推荐商家-- */
</style>
