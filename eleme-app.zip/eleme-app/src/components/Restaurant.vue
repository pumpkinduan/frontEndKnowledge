<template>
  <div class="restaurant_wrap clearfix">
    <div class="inner">
      <aside class="left_img_wrap">
        <img :src="restaurant.image_path">
      </aside>
      <div class="right_details_wrap">
        <h1 class="res_title">
          <span v-if="restaurant.is_premium" class="is_premium">品牌</span>
          {{restaurant.name}}
          </h1>
        <section>
          <div>
            <Rating 
              :rating="restaurant.rating"
            />
            <span class="rating">{{restaurant.rating}}</span>
            <span>月销售{{restaurant.recent_order_num}}</span>
          </div>
          <div>
            <span class="filter_sort">蜂鸟专送</span>
          </div>
        </section>
        <section>
          <div>
            <span>￥{{restaurant.float_minimum_order_amount}}起送</span>
            <span class="line">|</span>
            <span v-if="restaurant.float_delivery_fee">配送费￥{{restaurant.float_delivery_fee}}</span>
            <span v-else>免配送费</span>
          </div>
          <div>
            <span>{{(restaurant.distance / 1000).toFixed(2)}}km | {{restaurant.order_lead_time}}分钟</span>
          </div>
        </section>
        <section class="favors_tag">
          <div>
            <span v-for="(item, index) in restaurant.flavors" :key="'_'+index">{{item.name}}</span>
          </div>
        </section>
        <div class="activities clearfix">
          <ul>
            <li v-for="(item, index) in restaurant.activities.slice(0, 2)" :key="index">
              <span :style="{background: '#'+item.icon_color}" class="single_word">{{item.icon_name}}</span>
              <span class="tip">{{item.tips}}</span>
            </li>
            <li
              v-show="showMore"
              v-for="(item, index) in restaurant.activities.slice(2)"
              :key="index+2"
            >
              <span :style="{background: '#'+item.icon_color}" class="single_word">{{item.icon_name}}</span>
              <span class="tip">{{item.tips}}</span>
            </li>
          </ul>
          <div
            v-if="restaurant.activities && restaurant.activities.length>2"
            @click="showMore=!showMore"
          >
            {{restaurant.activities.length}}个活动
            <i
              :class="['iconfont','icon-xiala', (showMore ? 'active' : '')]"
            ></i>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import Rating from '@/components/Rating'
export default {
  components: {
    Rating
  },
  props: {
    restaurant: Object
  },
  data() {
    return {
      showMore: false
    };
  }
};
</script>
<style scoped>
.restaurant_wrap {
  padding: 0 5vw 3vw 2vw;
  border-bottom: 1px solid #ddd;
  margin-bottom: 5vw;
}
/* 左边 */
.left_img_wrap {
  width: 20vw;
  height: 20vw;
  float: left;
  padding: 0 2vw;
  box-sizing: border-box;
  margin-right: 3vw;
}
.left_img_wrap img {
  width: 100%;
  border: 1px solid #eee;
  display: block;
}
/* 右边 */
.right_details_wrap {
  float: right;
  width: 70vw;
}
.right_details_wrap .res_title {
  margin-bottom: 3vw;
  font-size: 16px;
  overflow: hidden;
  width: 80%;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.right_details_wrap section {
  margin-bottom: 3vw;
  font-size: 12px;
  color: rgb(107, 99, 99);
  display: flex;
  justify-content: space-between;
}
.right_details_wrap section span {
  margin-right: 1vw;
}
.right_details_wrap section.favors_tag span {
  background: #fafafa;
  border: 1px solid #eee;
}

.right_details_wrap section span.filter_sort {
  background: #0af;
  color: #fff;
  padding: 0 1vw;
}
.activities ul {
  float: left;
  width: 75%;
}
.activities ul li {
  padding: 2vw 0;
  transition: all 0.4s;
}
.activities ul li span {
  margin-right: 1vw;
}
.activities div {
  float: right;
  width: 25%;
}
.activities span.tip {
  display: inline-block;
  overflow: hidden;
  width: 80%;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.activities span.single_word {
  padding: 1vw;
  color: #fff;
  border-radius: 6px;
  text-align: center;
}
.icon-xiala {
  display: inline-block;
  transition: all 0.4s;
}
.active {
  transform: rotate(180deg) !important;
}
.line {
  margin: none !important;
}
.is_premium {
  color: #666;
  padding: 1.6vw;
  background: #ffe578;
  font-weight: 700;
  display: inline-block;
  border-radius: .1rem;
}
</style>


