let http = require('http');
let url = require('url');
let map = new Map();//用来存储手机号以及手机号对应的验证码
http.createServer(function (req, res) {
    let pathname = url.parse(req.url).pathname;
    let params = url.parse(req.url, true).query;
    let validatedCode = generateCode();
    if (pathname === '/getVertifyCode') {
        //将随机生成的验证码发给前台,利用该验证码可以成功登录
        map.set(params.mobile, validatedCode);
        res.writeHead(200, 'OK', { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Methods': 'GET', 'Access-Control-Expose-Headers': 'content-type, x-requested-with' });
        res.end(JSON.stringify({code: validatedCode, statusCode: 1}));
    } else if ( pathname === '/login' ) {
        //登录时对手机号与验证码进行校核
        let curCode = map.get(params.mobile);
        if ( curCode !== params.validatedCode ) {
            res.writeHead(200, 'OK', { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Methods': 'GET', 'Access-Control-Expose-Headers': 'content-type, x-requested-with' });
            res.end(JSON.stringify({reason: '验证码错误', statusCode: 0}));
        } else {
            res.writeHead(200, 'OK', { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Methods': 'GET', 'Access-Control-Expose-Headers': 'content-type, x-requested-with' });
            res.end(JSON.stringify({reason: 'success', statusCode: 1}));
        }
    }
}).listen(8888, function () {
    console.log('serve is running');
});

//生成6位数的验证码
function generateCode() {
    let validatedCode = Math.floor(Math.random() * 1000000);
    //必须返回字符串类型的
    return validatedCode.length < 6 ?  ('0' + validatedCode) : '' + validatedCode;
}