<template>
  <header>
    <i class="iconfont icon-zuo" @click="$router.go(-1)" v-show="!isBackupIcon"></i>
    <h1>{{ title }}</h1>
    <span>{{ subTitle }}</span>
  </header>
</template>
<script>
export default {
    props: {
        title: String,
        isBackupIcon: Boolean,
        subTitle: String
    }
};
</script>
<style scoped>
header {
  background: linear-gradient(90deg, #0af, #0085ff);
  width: 100vw;
  height: 12vw;
  display: flex;
  justify-content: space-around;
  align-items: center;
  color: #fff;
  font-weight: bolder;
  font-size: 18px;
}
.address header h1 {
  font-size: 0.2rem;
}
</style>


